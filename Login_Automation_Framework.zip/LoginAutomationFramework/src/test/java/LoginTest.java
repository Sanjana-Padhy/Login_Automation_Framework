import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class LoginTest {

    WebDriver driver;

    @BeforeMethod
    public void setup() {

        WebDriverManager.chromedriver().setup();

        driver = new ChromeDriver();

        driver.manage().window().maximize();

        driver.get("https://practicetestautomation.com/practice-test-login/");
    }

    @Test
    public void validLoginTest() {

        driver.findElement(By.id("username")).sendKeys("student");

        driver.findElement(By.id("password")).sendKeys("Password123");

        driver.findElement(By.id("submit")).click();

        String actualTitle = driver.getTitle();

        Assert.assertEquals(
                actualTitle,
                "Logged In Successfully | Practice Test Automation"
        );
    }

    @Test
    public void invalidPasswordTest() {

        driver.findElement(By.id("username")).sendKeys("student");

        driver.findElement(By.id("password")).sendKeys("WrongPassword");

        driver.findElement(By.id("submit")).click();

        String errorMessage =
                driver.findElement(By.id("error")).getText();

        Assert.assertTrue(
                errorMessage.contains("Your password is invalid!")
        );
    }

    @Test
    public void invalidUsernameTest() {

        driver.findElement(By.id("username")).sendKeys("wronguser");

        driver.findElement(By.id("password")).sendKeys("Password123");

        driver.findElement(By.id("submit")).click();

        String errorMessage =
                driver.findElement(By.id("error")).getText();

        Assert.assertTrue(
                errorMessage.contains("Your username is invalid!")
        );
    }

    @AfterMethod
    public void tearDown() {

        driver.quit();
    }
}